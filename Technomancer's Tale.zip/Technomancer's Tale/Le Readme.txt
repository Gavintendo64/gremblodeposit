<Technomancer's Tale Version 0.0.6> (C) Gavintendo64 2015

Doukutsu.exe - Main Game Program
DoConfig.exe - Game Configuration utility
Manual.html - Explains the game's mechanics and troubleshooting options
Profile.dat - Save data (appears after first save.)

Here is the address of the author's Email.
Gavintendo64@gmail.com

--The map is not usable unless you have the "Map System" item.
--If you have problems with getting two arrow keys to work at once, please use the < > ? settings.
--Please use Courier New as the font. Others cannot be guaranteed to work.
--If the keyboard controls are not responding, please disable "Use Gamepad" through DoConfig.exe.

Thanks to:
Randolf (Beta testing, inspiration, swag, Infinite Mimiga Mask Mod Help, help in general)
Lace (Infinite Mimiga Mask Mod)
Knuckles5577 (Infinite Mimiga Mask Mod Help, help in general)
Randolf (Yes, he has to be here twice.)
Elijah (Support, Beta testing, swag)
Creators of Usenti (For getting me out of a fuzzy pickle.)
Pixel (The game in the first place, Immense swag)
Noxid (He's Noxid. wut else do i have to say?)
Doors (Because I cant nueter her}
And whoever helped in any way.

THIS UPDATE WAS HARD AS MY-
uh... nevermind.
Thanks For Playing!